#!/usr/bin/env bash
# Upload this sample to a running vil-server (default: http://localhost:3080).
# Usage:
#   ./curl-upload.sh                                    # localhost, no auth
#   ./curl-upload.sh http://vil-server.example.com      # custom host
#   ADMIN_KEY=secret ./curl-upload.sh                   # with auth
set -euo pipefail

HOST="${1:-http://localhost:3080}"
AUTH=()
if [[ -n "${ADMIN_KEY:-}" ]]; then
  AUTH=(-H "X-Admin-Key: ${ADMIN_KEY}")
fi

cd "$(dirname "$0")"

echo "▸ Uploading to $HOST"

for w in *.wasm; do
  [[ -f "$w" ]] || continue
  ref="${w%.wasm}"
  echo "  WASM : $ref"
  curl -fsS -X POST "$HOST/api/admin/upload/wasm" \
    "${AUTH[@]}" \
    -H "X-Module-Ref: $ref" \
    --data-binary "@$w" | head -c 200 ; echo
done

for y in *.yaml *.yml; do
  [[ -f "$y" ]] || continue
  echo "  YAML : $(basename "$y")"
  curl -fsS -X POST "$HOST/api/admin/upload" \
    "${AUTH[@]}" \
    -H 'Content-Type: application/x-yaml' \
    --data-binary "@$y" | head -c 200 ; echo
done

echo ""
echo "✓ All uploaded. Hit your endpoint at $HOST/<webhook_path>"
