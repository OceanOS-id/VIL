# VIL Sample — ai-gateway (v0.4.0)

Ready-to-upload workflow for a running `vil-server` — YAML + WASM pre-built. This sample talks to an upstream (`ai-endpoint-simulator`), install shown below.

## 60-Second Demo

```bash
# 0. (prerequisite) Install + start the upstream this workflow talks to:
#    ai-endpoint-simulator — binary is on crates.io
cargo install ai-endpoint-simulator
ai-endpoint-simulator &

# 1. Start the provisionable VIL server
docker run -d --network host --name vil vilfounder/vil:0.4.0

# 2. Upload this sample (all workflows + any WASM modules)
./curl-upload.sh

# 3. Hit the endpoint
curl -X POST http://localhost:3080/trigger \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"hello"}'
```

## Contents

| File | Role |
|------|------|
| `ai-gateway.yaml` | VWFD workflow definition |

| `curl-upload.sh` | One-shot upload script (uploads YAML + any WASM modules via admin API) |
| `README.md` | This file |

## Activity Types in This Sample

- `Connector`
- `End`
- `EndTrigger`
- `Trigger`

## Teardown

```bash
docker rm -f vil
pkill -f ai-endpoint-simulator
```

## License

This sample is distributed alongside VIL source under the same licensing terms — library code is Apache 2.0 / MIT, VIL workflow runtime is VSAL. See [LICENSING.md](https://github.com/OceanOS-id/VIL/blob/main/LICENSING.md) — internal business use is free; operating as a multi-tenant Workflow-as-a-Service requires a commercial agreement with Vastar.
